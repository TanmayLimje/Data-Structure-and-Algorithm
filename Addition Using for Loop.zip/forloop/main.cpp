#include <iostream>

using namespace std;

int main()
{
    int sum=0;
    for(int i = 1; i<=10; i++)
    {

        sum = sum + i;
        cout << i << endl;
    }
     cout << "the addition is:" << sum;
}

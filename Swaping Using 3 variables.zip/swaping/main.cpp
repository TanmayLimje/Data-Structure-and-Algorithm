#include <iostream>

using namespace std;

void swaps( int x , int y )
{
    int z;
    z = x;
    x = y;
    y = z;
    cout << endl << " after swaping" << endl;
    cout << x << "  "<<  y;
}

int main()
{
    int a , b ;

    cout << "enter 1st value" << endl;
    cin >> a;

    cout << "enter 2nd value" << endl;
    cin >> b;

    cout << "before swaping" << endl;
    cout << a << "  " << b;

    swaps(a,b);

    return 0;
}
